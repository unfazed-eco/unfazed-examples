from pydantic.fields import FieldInfo


class Doc(FieldInfo):
    pass
