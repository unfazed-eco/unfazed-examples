from .default import DefaultAuthBackend

__all__ = ["DefaultAuthBackend"]
